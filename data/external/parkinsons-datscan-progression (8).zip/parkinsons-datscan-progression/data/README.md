# Data Directory (gitignored)

This folder is intentionally empty in the GitHub repo. PPMI's Data Use Agreement prohibits
redistributing subject-level data, so raw and processed data are never committed here.

## To reproduce

1. Register at https://www.ppmi-info.org/access-data-specimens/download-data and accept the
   Data Use Agreement.
2. Download the files listed in `../docs/03_data_dictionary.md`.
3. Place raw exports under `data/raw/` (subfolders as named in the dictionary).
4. Run the merge pipeline in `src/data/` to populate `data/processed/`.

## Structure once populated

```
data/
├── raw/            # exact PPMI exports, untouched
└── processed/      # merged patient-visit master table(s), versioned by date/pipeline run
```
