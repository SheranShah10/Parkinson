"""
Evaluation metrics. Regression is used for severity, classification for stage.
Classification always reports macro/balanced metrics as primary -- see D016 on why raw
accuracy is actively misleading for the stage task.
"""
import numpy as np
from sklearn.metrics import (
    mean_absolute_error, mean_squared_error, r2_score,
    accuracy_score, balanced_accuracy_score, f1_score, matthews_corrcoef,
    cohen_kappa_score, confusion_matrix, classification_report,
)


def regression_metrics(y_true, y_pred) -> dict:
    return {
        "MAE": mean_absolute_error(y_true, y_pred),
        "RMSE": mean_squared_error(y_true, y_pred) ** 0.5,
        "R2": r2_score(y_true, y_pred),
    }


def classification_metrics(y_true, y_pred) -> dict:
    """Accuracy is reported for completeness but should never be read as the primary metric
    on the stage task given the class imbalance documented in D016 -- balanced accuracy,
    macro-F1, MCC, and Cohen's kappa are the primary metrics.
    """
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "balanced_accuracy": balanced_accuracy_score(y_true, y_pred),
        "macro_f1": f1_score(y_true, y_pred, average="macro"),
        "MCC": matthews_corrcoef(y_true, y_pred),
        "cohen_kappa": cohen_kappa_score(y_true, y_pred),
        "confusion_matrix": confusion_matrix(y_true, y_pred).tolist(),
        "per_class_report": classification_report(y_true, y_pred, output_dict=True, zero_division=0),
    }
