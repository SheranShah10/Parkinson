"""
Splitting utilities.

D013 (see docs/01_decision_log.md): 927 of 1,394 patients (66.5%) in the imaging-anchored
cohort have more than one visit-record. A naive row-level train/test split would let the same
patient's visits land in both train and test, letting a model partly identify "this patient"
rather than learn generalizable severity/stage signal from imaging and clinical features.

All modeling code MUST split by PATNO (patient), never by row, for both the main train/test
split and any cross-validation. Use `patient_level_train_test_split` / `PatientGroupKFold`
below rather than sklearn's default row-level splitters directly.
"""
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupShuffleSplit, GroupKFold


def patient_level_train_test_split(df: pd.DataFrame, test_size: float = 0.2, random_state: int = 42,
                                    patient_col: str = "PATNO"):
    """Splits by patient, not by row -- no PATNO appears in both the train and test output."""
    splitter = GroupShuffleSplit(n_splits=1, test_size=test_size, random_state=random_state)
    train_idx, test_idx = next(splitter.split(df, groups=df[patient_col]))
    train_df, test_df = df.iloc[train_idx], df.iloc[test_idx]
    overlap = set(train_df[patient_col]) & set(test_df[patient_col])
    assert len(overlap) == 0, f"Patient-level split failed: {len(overlap)} patients in both sets"
    return train_df, test_df


def patient_group_kfold(df: pd.DataFrame, n_splits: int = 5, patient_col: str = "PATNO"):
    """Group-aware K-fold cross-validation -- yields (train_idx, val_idx) with no PATNO
    appearing in both the train and validation fold for a given split.
    """
    gkf = GroupKFold(n_splits=n_splits)
    return gkf.split(df, groups=df[patient_col])
