"""
Feature engineering for the severity/stage modeling tasks.

Every derived feature here has a corresponding row in docs/04_feature_dictionary.md with
source, clinical meaning, and leakage-risk assessment -- keep them in sync.
"""
import pandas as pd
import numpy as np


def _parse_mmyyyy(series: pd.Series) -> pd.Series:
    """PPMI de-identifies dates to MM/YYYY (no day) -- parse as the 1st of the month."""
    return pd.to_datetime(series, format="%m/%Y", errors="coerce")


def compute_age_at_visit(df: pd.DataFrame, birthdt_col="BIRTHDT", visit_date_col="INFODT") -> pd.Series:
    """Age in years at the visit date. Both PPMI date fields are MM/YYYY (day redacted for
    de-identification), so this is accurate to within ~1 year, not to the day -- document this
    granularity limit wherever age is reported in the paper, don't imply day-level precision.
    """
    birth = _parse_mmyyyy(df[birthdt_col]) if not pd.api.types.is_datetime64_any_dtype(df[birthdt_col]) else df[birthdt_col]
    visit = df[visit_date_col] if pd.api.types.is_datetime64_any_dtype(df[visit_date_col]) else _parse_mmyyyy(df[visit_date_col])
    age_days = (visit - birth).dt.days
    return age_days / 365.25


def compute_asymmetry_features(df: pd.DataFrame, region: str, relative_floor: float = 0.25) -> pd.DataFrame:
    """Asymmetry Index (AI) for a bilateral SBR region: AI = (R - L) / (R + L) * 100.
    Standard construct in DAT-SPECT PD literature -- PD typically has asymmetric onset, so
    this is a clinically motivated derived feature, not an arbitrary one.

    The ratio form is numerically unstable when (L + R) is small relative to this region's
    typical scale -- which happens at near-total dopaminergic depletion (severe/end-stage
    bilateral disease), producing percentages in the hundreds that don't mean what a normal
    AI value means. A fixed absolute cutoff doesn't generalize across regions with different
    natural SBR scales (striatum vs. putamen vs. caudate), so the floor here is relative:
    `relative_floor` x the region's own median (L+R) magnitude. Rows below it get AI set to
    NaN (not a fabricated extreme value) and are marked in `{region}_AI_unstable_flag`. A raw,
    division-free `{region}_diff` (R - L) is always provided as a stable alternative.

    Returns columns: `{region}_diff`, `{region}_AI`, `{region}_AI_abs`, `{region}_AI_unstable_flag`.
    """
    l_col, r_col = f"{region}_L_REF_CWM", f"{region}_R_REF_CWM"
    df = df.copy()
    denom = df[l_col] + df[r_col]
    scale = denom.abs().median()
    denom_floor = relative_floor * scale
    unstable = denom.abs() < denom_floor

    diff = df[r_col] - df[l_col]
    ai = (diff / denom.replace(0, np.nan) * 100)
    ai = ai.where(~unstable, np.nan)

    df[f"{region}_diff"] = diff
    df[f"{region}_AI"] = ai
    df[f"{region}_AI_abs"] = ai.abs()
    df[f"{region}_AI_unstable_flag"] = unstable.fillna(False)
    return df


def build_candidate_features(demographics: pd.DataFrame, imaging_anchored: pd.DataFrame) -> pd.DataFrame:
    """Assemble the candidate feature set for severity/stage modeling on the imaging-anchored
    cohort. This produces *candidates* -- final feature selection (with leakage sign-off) is a
    separate, later phase per the project roadmap; this function doesn't decide what a model
    actually uses.
    """
    df = imaging_anchored.copy()

    demo_slim = demographics.sort_values("PATNO").drop_duplicates(subset="PATNO")[
        ["PATNO", "SEX", "BIRTHDT", "HANDED", "RAWHITE"]
    ]
    df = df.merge(demo_slim, on="PATNO", how="left")
    df["AGE_AT_VISIT"] = compute_age_at_visit(df, "BIRTHDT", "DATSCAN_DATE")

    for region in ["STRIATUM", "PUTAMEN", "CAUDATE"]:
        df = compute_asymmetry_features(df, region)

    return df
