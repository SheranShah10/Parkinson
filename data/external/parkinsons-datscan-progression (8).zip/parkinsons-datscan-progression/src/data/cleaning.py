"""
Data cleaning / validation logic for the Data Cleaning phase.

Philosophy (per project principles): flag anomalies explicitly, never silently drop or
clip clinical/imaging values. Rows are only excluded when there's a documented, evidence-backed
reason (see docs/01_decision_log.md), never as an automatic outlier-removal step -- severe
disease cases are exactly the cases later error-analysis and ablation work care about most.
"""
import pandas as pd
import numpy as np

# Theoretical valid ranges for clinical scales
VALID_RANGES = {
    "NP3TOT": (0, 132),   # 33 items x 0-4
    "NP2PTOT": (0, 52),   # 13 items x 0-4
    "NHY": (0, 5),        # Hoehn & Yahr, already cleaned of the 101-code in merge.clean_nhy
}

# Composite SBR regions where a negative value is clinically implausible (signal should be
# strongly positive even in severe disease) -- distinct from posterior-caudate sub-regions,
# where near-zero/negative values are an expected quantification artifact of a naturally
# low-signal reference region and are NOT flagged as row-level anomalies.
COMPOSITE_SBR_COLS = ["STRIATUM_REF_CWM", "STRIATUM_L_REF_CWM", "STRIATUM_R_REF_CWM",
                       "PUTAMEN_REF_CWM", "PUTAMEN_L_REF_CWM", "CAUDATE_REF_CWM"]


def validate_ranges(df: pd.DataFrame) -> dict:
    """Check clinical scale columns against their theoretical valid ranges.
    Returns a dict of {column: count_out_of_range}. Should be empty/zero on clean data --
    this is a guard-rail check, not a cleaning step itself.
    """
    violations = {}
    for col, (lo, hi) in VALID_RANGES.items():
        if col in df.columns:
            n_bad = ((df[col] < lo) | (df[col] > hi)).sum()
            if n_bad > 0:
                violations[col] = int(n_bad)
    return violations


def flag_sbr_anomalies(df: pd.DataFrame, iqr_multiplier: float = 3.0) -> pd.DataFrame:
    """D009: flag (never drop) two categories of SBR anomaly:
    1. Negative values in composite regions (STRIATUM/PUTAMEN/CAUDATE) -- implausible, rare
       (2 rows in the imaging-anchored cohort as of the first EDA pass).
    2. Extreme outliers via a wide (3x, not the usual 1.5x) IQR fence on the three primary
       composite columns -- wide fence chosen deliberately since UPDRS/imaging severity
       legitimately has a heavy right tail; 1.5x would flag genuine severe-disease cases as
       "errors," which they are not.
    """
    df = df.copy()
    for col in COMPOSITE_SBR_COLS:
        if col not in df.columns:
            continue
        flag_col = f"{col}_negative_flag"
        df[flag_col] = df[col] < 0

    for col in ["STRIATUM_REF_CWM", "PUTAMEN_REF_CWM", "CAUDATE_REF_CWM"]:
        if col not in df.columns:
            continue
        q1, q3 = df[col].quantile([0.25, 0.75])
        iqr = q3 - q1
        lo, hi = q1 - iqr_multiplier * iqr, q3 + iqr_multiplier * iqr
        df[f"{col}_extreme_outlier_flag"] = (df[col] < lo) | (df[col] > hi)

    return df
