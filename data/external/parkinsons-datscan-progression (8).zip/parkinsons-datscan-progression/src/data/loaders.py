"""
Loaders for raw PPMI export tables used in this project.

Each function loads exactly one raw file and does the minimum necessary type
coercion (dates, numeric NHY) -- no merging, cleaning-decisions, or feature
engineering happens here. See src/data/merge.py for everything downstream.
"""
from pathlib import Path
import pandas as pd

RAW_DIR = Path("data/raw")


def load_demographics(path: Path = None) -> pd.DataFrame:
    path = path or RAW_DIR / "Demographics_14Feb2026.csv"
    df = pd.read_csv(path)
    return df


def load_updrs_ii(path: Path = None) -> pd.DataFrame:
    path = path or RAW_DIR / "MDS_UPDRS_Part_II__Patient_Questionnaire_14Feb2026.csv"
    df = pd.read_csv(path)
    return df


def load_updrs_iii(path: Path = None) -> pd.DataFrame:
    path = path or RAW_DIR / "MDS-UPDRS_Part_III_14Feb2026.csv"
    df = pd.read_csv(path, low_memory=False)
    df["INFODT"] = pd.to_datetime(df["INFODT"], errors="coerce", format="mixed")
    df["NHY"] = pd.to_numeric(df["NHY"], errors="coerce")
    return df


def load_datscan_imaging_meta(path: Path = None) -> pd.DataFrame:
    path = path or RAW_DIR / "DaTscan_Imaging_14Feb2026.csv"
    df = pd.read_csv(path)
    df["INFODT"] = pd.to_datetime(df["INFODT"], errors="coerce", format="mixed")
    return df


def load_sbr(path: Path = None) -> pd.DataFrame:
    path = path or RAW_DIR / "Xing_Core_Lab_-_Quant_SBR_14Feb2026.csv"
    df = pd.read_csv(path)
    df["DATSCAN_DATE"] = pd.to_datetime(df["DATSCAN_DATE"], errors="coerce", format="mixed")
    return df
