"""
Cleaning and merge logic for the patient-visit master table.

Every function here implements a specific decision recorded in
docs/01_decision_log.md. Do not change this logic without updating that log
entry -- decisions and code must stay in sync.
"""
import pandas as pd
import numpy as np


def clean_nhy(df: pd.DataFrame, valid_range=(0, 5)) -> pd.DataFrame:
    """D004: NHY values outside [0,5] (e.g. the 101 code) are set to NaN, not guessed at."""
    df = df.copy()
    lo, hi = valid_range
    invalid_mask = ~df["NHY"].between(lo, hi) & df["NHY"].notna()
    df.loc[invalid_mask, "NHY_invalid_raw"] = df.loc[invalid_mask, "NHY"]
    df.loc[invalid_mask, "NHY"] = np.nan
    return df


def resolve_on_off_duplicates(df: pd.DataFrame) -> pd.DataFrame:
    """D005: when a PATNO+EVENT_ID visit has both ON and OFF state exams, OFF is canonical.
    The ON-state NP3TOT is preserved in a secondary column for sensitivity analysis.

    Implemented via sort + drop_duplicates rather than groupby.apply, since the latter
    is both slower here and (as of pandas 3.0) silently drops the grouping-key columns
    from a Series-valued apply result -- confirmed via direct test during development.
    """
    df = df.copy()
    df["PDSTATE_norm"] = df["PDSTATE"].fillna("UNKNOWN")
    df["_state_priority"] = df["PDSTATE_norm"].map({"OFF": 0, "ON": 1}).fillna(2)

    on_rows = df[df["PDSTATE_norm"] == "ON"][["PATNO", "EVENT_ID", "NP3TOT"]].rename(
        columns={"NP3TOT": "NP3TOT_ON_secondary"}
    )
    on_rows = on_rows.drop_duplicates(subset=["PATNO", "EVENT_ID"])

    state_counts = (
        df[df["PDSTATE_norm"].isin(["ON", "OFF"])]
        .groupby(["PATNO", "EVENT_ID"])["PDSTATE_norm"]
        .nunique()
        .rename("_n_states")
        .reset_index()
    )

    canonical = (
        df.sort_values(["PATNO", "EVENT_ID", "_state_priority"])
        .drop_duplicates(subset=["PATNO", "EVENT_ID"], keep="first")
        .drop(columns=["_state_priority"])
    )
    canonical = canonical.merge(on_rows, on=["PATNO", "EVENT_ID"], how="left")
    canonical = canonical.merge(state_counts, on=["PATNO", "EVENT_ID"], how="left")
    canonical["visit_had_on_off_duplicate"] = canonical["_n_states"].fillna(0) >= 2
    canonical = canonical.drop(columns=["_n_states"])
    return canonical.reset_index(drop=True)


def merge_clinical_with_sbr(
    clinical: pd.DataFrame,
    sbr: pd.DataFrame,
    tolerance_days: int = 90,
) -> pd.DataFrame:
    """D006: link SBR (imaging) rows to clinical visit rows by nearest INFODT/DATSCAN_DATE
    within `tolerance_days`, per patient -- NOT by matching EVENT_ID strings, since the two
    tables use different visit-code vocabularies.
    """
    matched_rows = []
    clinical_by_pt = {pt: g for pt, g in clinical.dropna(subset=["INFODT"]).groupby("PATNO")}

    for _, srow in sbr.dropna(subset=["DATSCAN_DATE"]).iterrows():
        pt = srow["PATNO"]
        if pt not in clinical_by_pt:
            continue
        g = clinical_by_pt[pt]
        deltas = (g["INFODT"] - srow["DATSCAN_DATE"]).abs()
        best_idx = deltas.idxmin()
        if deltas.loc[best_idx] <= pd.Timedelta(days=tolerance_days):
            crow = g.loc[best_idx]
            combined = {**srow.to_dict(), **{f"clinical_{k}": v for k, v in crow.to_dict().items()}}
            combined["match_delta_days"] = deltas.loc[best_idx].days
            matched_rows.append(combined)

    return pd.DataFrame(matched_rows)


def flag_remote_visits(df: pd.DataFrame, event_col: str = "EVENT_ID") -> pd.DataFrame:
    """D008: NP3TOT (severity) is missing in 91.9% of 'R'-prefixed (remote/telehealth) visits,
    vs. 0.4-1.6% at in-person visit types (SC/BL/ST) -- because the motor exam requires
    physical contact (rigidity, finger-tapping) that can't be done over video. This is
    structural missingness tied to visit modality, not something to impute.

    Adds `is_remote_visit` and `severity_target_eligible` (False for remote visits) so
    downstream modeling can exclude these rows from severity training/evaluation without
    losing them for other purposes (e.g. NHY/stage, which degrades far less at remote visits:
    22.2% missing vs. 91.9% for NP3TOT, since stage can be partly judged by observation).
    """
    df = df.copy()
    df["is_remote_visit"] = df[event_col].astype(str).str.match(r"^R\d+$", na=False)
    df["severity_target_eligible"] = ~df["is_remote_visit"]
    return df


def build_master_table(demographics, updrs_ii, updrs_iii, sbr, tolerance_days: int = 90):
    """Orchestrates the full merge per the decision log:
    1. Clean NHY (D004)
    2. Resolve ON/OFF duplicates in UPDRS-III (D005)
    3. Merge clinical + SBR by date proximity (D006)
    4. Attach demographics and UPDRS-II (functional severity, secondary target)

    Returns a dict of DataFrames: {"clinical_only": ..., "imaging_anchored": ...}
    so downstream work can choose the right cohort for the right task.
    """
    u3_clean = clean_nhy(updrs_iii)
    u3_resolved = resolve_on_off_duplicates(u3_clean)

    u3_flagged = flag_remote_visits(u3_resolved)

    # Clinical-only cohort (stage + severity, no imaging requirement)
    clinical_only = u3_flagged.merge(demographics, on="PATNO", how="left", suffixes=("", "_demo"))
    clinical_only = clinical_only.merge(
        updrs_ii[["PATNO", "EVENT_ID", "NP2PTOT"]], on=["PATNO", "EVENT_ID"], how="left"
    )

    # Imaging-anchored cohort (stage + severity + DaTSCAN SBR together)
    imaging_anchored = merge_clinical_with_sbr(u3_flagged, sbr, tolerance_days=tolerance_days)
    imaging_anchored = imaging_anchored.merge(
        updrs_ii[["PATNO", "EVENT_ID", "NP2PTOT"]].rename(
            columns={"EVENT_ID": "clinical_EVENT_ID", "NP2PTOT": "clinical_NP2PTOT"}
        ),
        on=["PATNO", "clinical_EVENT_ID"], how="left",
    )

    return {"clinical_only": clinical_only, "imaging_anchored": imaging_anchored}
