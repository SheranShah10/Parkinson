"""
Tabular deep learning models.

Implementation notes (read before citing these as faithful reproductions in the paper):
- MLP, ResNet (tabular): standard, faithful implementations (Gorishniy et al. 2021 style).
- FTTransformer: implemented from scratch here (feature tokenizer + transformer encoder +
  CLS token) rather than depending on the `rtdl` package, to avoid version-compatibility
  issues -- this is a faithful implementation of the core architecture, not a simplification.
- SAINTSimplified: SAINT's actual architecture alternates attention over *features* with
  attention over *samples in the batch* (intersample attention), plus a contrastive
  self-supervised pretraining stage. This implementation includes both attention types but
  OMITS the contrastive pretraining stage -- it is supervised-only. Report it in the paper as
  "SAINT (simplified, no contrastive pretraining)", not as SAINT.
- TabMSimplified: TabM's actual method uses BatchEnsemble-style efficient weight-sharing
  across an implicit ensemble of MLPs with per-member scaling vectors. This implementation
  follows that core idea (shared weight matrices, per-member input/output scaling) but has not
  been checked against the official TabM repo for exact parameterization. Report it in the
  paper as "TabM (simplified reimplementation)", not as TabM.
"""
import torch
import torch.nn as nn


class MLP(nn.Module):
    def __init__(self, n_features, n_outputs, hidden_dims=(128, 64), dropout=0.2):
        super().__init__()
        layers = []
        d = n_features
        for h in hidden_dims:
            layers += [nn.Linear(d, h), nn.ReLU(), nn.BatchNorm1d(h), nn.Dropout(dropout)]
            d = h
        layers.append(nn.Linear(d, n_outputs))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)


class ResNetBlock(nn.Module):
    def __init__(self, d, hidden_mult=2, dropout=0.2):
        super().__init__()
        self.norm = nn.BatchNorm1d(d)
        self.lin1 = nn.Linear(d, d * hidden_mult)
        self.lin2 = nn.Linear(d * hidden_mult, d)
        self.dropout = nn.Dropout(dropout)
        self.act = nn.ReLU()

    def forward(self, x):
        h = self.norm(x)
        h = self.act(self.lin1(h))
        h = self.dropout(h)
        h = self.lin2(h)
        return x + h


class TabularResNet(nn.Module):
    def __init__(self, n_features, n_outputs, d_main=128, n_blocks=4, dropout=0.2):
        super().__init__()
        self.input_proj = nn.Linear(n_features, d_main)
        self.blocks = nn.Sequential(*[ResNetBlock(d_main, dropout=dropout) for _ in range(n_blocks)])
        self.head = nn.Sequential(nn.BatchNorm1d(d_main), nn.ReLU(), nn.Linear(d_main, n_outputs))

    def forward(self, x):
        x = self.input_proj(x)
        x = self.blocks(x)
        return self.head(x)


class FeatureTokenizer(nn.Module):
    """Numeric-only tokenizer: each feature gets its own learned linear projection into
    d_token, per Gorishniy et al. 2021. (This project's candidate features are all numeric
    post-encoding; categorical tokenization is not implemented since it isn't needed here.)
    """
    def __init__(self, n_features, d_token):
        super().__init__()
        self.weight = nn.Parameter(torch.randn(n_features, d_token) * 0.02)
        self.bias = nn.Parameter(torch.zeros(n_features, d_token))

    def forward(self, x):
        # x: (batch, n_features) -> (batch, n_features, d_token)
        return x.unsqueeze(-1) * self.weight + self.bias


class FTTransformer(nn.Module):
    def __init__(self, n_features, n_outputs, d_token=64, n_layers=3, n_heads=8, dropout=0.1):
        super().__init__()
        self.tokenizer = FeatureTokenizer(n_features, d_token)
        self.cls_token = nn.Parameter(torch.randn(1, 1, d_token) * 0.02)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_token, nhead=n_heads, dim_feedforward=d_token * 4,
            dropout=dropout, batch_first=True, activation="gelu",
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)
        self.head = nn.Sequential(nn.LayerNorm(d_token), nn.ReLU(), nn.Linear(d_token, n_outputs))

    def forward(self, x):
        tokens = self.tokenizer(x)  # (batch, n_features, d_token)
        cls = self.cls_token.expand(x.shape[0], -1, -1)
        tokens = torch.cat([cls, tokens], dim=1)
        encoded = self.encoder(tokens)
        return self.head(encoded[:, 0])  # CLS token output


class SAINTSimplified(nn.Module):
    """Simplified SAINT -- see module docstring: no contrastive pretraining."""
    def __init__(self, n_features, n_outputs, d_token=64, n_layers=2, n_heads=8, dropout=0.1):
        super().__init__()
        self.tokenizer = FeatureTokenizer(n_features, d_token)
        self.cls_token = nn.Parameter(torch.randn(1, 1, d_token) * 0.02)
        self.feature_attn_layers = nn.ModuleList([
            nn.TransformerEncoderLayer(d_model=d_token, nhead=n_heads, dim_feedforward=d_token * 4,
                                        dropout=dropout, batch_first=True, activation="gelu")
            for _ in range(n_layers)
        ])
        # Intersample attention: attends across the batch dimension for each (feature+1) slot
        self.intersample_attn_layers = nn.ModuleList([
            nn.MultiheadAttention(embed_dim=d_token, num_heads=n_heads, dropout=dropout, batch_first=True)
            for _ in range(n_layers)
        ])
        self.intersample_norms = nn.ModuleList([nn.LayerNorm(d_token) for _ in range(n_layers)])
        self.head = nn.Sequential(nn.LayerNorm(d_token), nn.ReLU(), nn.Linear(d_token, n_outputs))

    def forward(self, x):
        tokens = self.tokenizer(x)
        cls = self.cls_token.expand(x.shape[0], -1, -1)
        tokens = torch.cat([cls, tokens], dim=1)  # (batch, seq, d_token)
        for feat_layer, inter_layer, inter_norm in zip(self.feature_attn_layers, self.intersample_attn_layers, self.intersample_norms):
            tokens = feat_layer(tokens)
            # intersample attention: transpose so "batch" (samples) becomes the attention axis
            b, s, d = tokens.shape
            t = tokens.transpose(0, 1)  # (seq, batch, d_token) -> treat seq as batch for attn
            attn_out, _ = inter_layer(t, t, t)
            t = inter_norm(t + attn_out)  # residual + LayerNorm -- missing in the original pass (D017)
            tokens = t.transpose(0, 1)
        return self.head(tokens[:, 0])


class TabMSimplified(nn.Module):
    """Simplified TabM -- see module docstring: parameter-efficient MLP ensemble via
    per-member scaling vectors on a shared backbone (BatchEnsemble-style), not verified
    against the official implementation's exact parameterization.
    """
    def __init__(self, n_features, n_outputs, hidden_dims=(128, 64), n_members=8, dropout=0.2):
        super().__init__()
        self.n_members = n_members
        d = n_features
        self.shared_layers = nn.ModuleList()
        self.in_scales = nn.ParameterList()
        self.out_scales = nn.ParameterList()
        for h in hidden_dims:
            self.shared_layers.append(nn.Linear(d, h))
            self.in_scales.append(nn.Parameter(torch.randn(n_members, d) * 0.02 + 1.0))
            self.out_scales.append(nn.Parameter(torch.randn(n_members, h) * 0.02 + 1.0))
            d = h
        self.output_head = nn.Linear(d, n_outputs)
        self.dropout = nn.Dropout(dropout)
        self.act = nn.ReLU()
        self.bn_layers = nn.ModuleList([nn.BatchNorm1d(h) for h in hidden_dims])

    def forward(self, x):
        # x: (batch, n_features) -> replicate across ensemble members
        b = x.shape[0]
        h = x.unsqueeze(0).expand(self.n_members, b, -1)  # (members, batch, features)
        for layer, in_s, out_s, bn in zip(self.shared_layers, self.in_scales, self.out_scales, self.bn_layers):
            h = h * in_s.unsqueeze(1)  # per-member input scaling
            h = layer(h)
            h = h * out_s.unsqueeze(1)  # per-member output scaling
            h = h.reshape(self.n_members * b, -1)
            h = self.act(bn(h))
            h = self.dropout(h)
            h = h.reshape(self.n_members, b, -1)
        out = self.output_head(h)  # (members, batch, n_outputs)
        return out.mean(dim=0)  # average ensemble predictions
