"""
Shared training loop for the deep learning models in deep_learning.py. Handles both the
severity (regression) and stage (classification) tasks, with an internal patient-level
train/validation split for early stopping (separate from the outer train/test split --
never uses test data for stopping decisions).
"""
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler

from src.utils.splitting import patient_level_train_test_split


def _prepare_arrays(train_df, val_df, test_df, feature_cols, target_col):
    imputer = SimpleImputer(strategy="median")
    scaler = StandardScaler()
    Xtr = scaler.fit_transform(imputer.fit_transform(train_df[feature_cols]))
    Xval = scaler.transform(imputer.transform(val_df[feature_cols]))
    Xte = scaler.transform(imputer.transform(test_df[feature_cols]))
    return (
        Xtr.astype(np.float32), Xval.astype(np.float32), Xte.astype(np.float32),
        train_df[target_col].values, val_df[target_col].values, test_df[target_col].values,
    )


def train_deep_model(model_fn, train_df, test_df, feature_cols, target_col, task: str,
                      n_classes: int = None, epochs: int = 100, patience: int = 15,
                      lr: float = 1e-3, batch_size: int = 64, random_state: int = 42,
                      class_weights: np.ndarray = None, warmup_epochs: int = 0):
    """
    model_fn: callable(n_features, n_outputs) -> nn.Module
    task: "regression" or "classification"
    warmup_epochs: linearly ramps lr from lr/10 to lr over this many epochs, then holds
        constant. Added specifically to test whether SAINT's training collapse (D017) is a
        warmup/optimization-sensitivity issue rather than an architectural one.
    Returns (trained_model, test_predictions, scaler_imputer_info) -- predictions are in
    original target units/classes (already inverse-processed where relevant).
    """
    torch.manual_seed(random_state)

    # internal patient-level train/val split for early stopping -- test set never touched
    inner_train, inner_val = patient_level_train_test_split(train_df, test_size=0.15, random_state=random_state)
    Xtr, Xval, Xte, ytr, yval, yte = _prepare_arrays(inner_train, inner_val, test_df, feature_cols, target_col)

    n_outputs = n_classes if task == "classification" else 1
    model = model_fn(len(feature_cols), n_outputs)

    if task == "regression":
        criterion = nn.MSELoss()
        ytr_t = torch.tensor(ytr, dtype=torch.float32).unsqueeze(1)
        yval_t = torch.tensor(yval, dtype=torch.float32).unsqueeze(1)
    else:
        weight = torch.tensor(class_weights, dtype=torch.float32) if class_weights is not None else None
        criterion = nn.CrossEntropyLoss(weight=weight)
        ytr_t = torch.tensor(ytr, dtype=torch.long)
        yval_t = torch.tensor(yval, dtype=torch.long)

    train_loader = DataLoader(
        TensorDataset(torch.tensor(Xtr), ytr_t), batch_size=batch_size, shuffle=True
    )
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)

    def lr_lambda(epoch):
        if warmup_epochs > 0 and epoch < warmup_epochs:
            return 0.1 + 0.9 * (epoch / warmup_epochs)
        return 1.0

    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda) if warmup_epochs > 0 else None

    best_val_loss, best_state, epochs_no_improve = float("inf"), None, 0

    for epoch in range(epochs):
        model.train()
        for xb, yb in train_loader:
            optimizer.zero_grad()
            pred = model(xb)
            loss = criterion(pred if task == "classification" else pred, yb)
            loss.backward()
            optimizer.step()
        if scheduler is not None:
            scheduler.step()

        model.eval()
        with torch.no_grad():
            val_pred = model(torch.tensor(Xval))
            val_loss = criterion(val_pred, yval_t).item()

        if val_loss < best_val_loss - 1e-4:
            best_val_loss, best_state, epochs_no_improve = val_loss, {k: v.clone() for k, v in model.state_dict().items()}, 0
        else:
            epochs_no_improve += 1
            if epochs_no_improve >= patience:
                break

    if best_state is not None:
        model.load_state_dict(best_state)

    model.eval()
    with torch.no_grad():
        test_pred = model(torch.tensor(Xte))
        if task == "regression":
            preds = test_pred.squeeze(1).numpy()
        else:
            preds = test_pred.argmax(dim=1).numpy()

    return model, preds, yte
