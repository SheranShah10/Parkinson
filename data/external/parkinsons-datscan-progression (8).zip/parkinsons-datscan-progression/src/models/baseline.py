"""
Baseline models: Logistic/Linear Regression, Random Forest, XGBoost.

Note on task/algorithm matching (see D016): Logistic Regression is a classification
algorithm and cannot target a continuous score. For the severity task (NP3TOT, continuous),
its regression counterpart -- Ridge Regression -- is used instead of forcing a classifier
onto a regression target. Random Forest and XGBoost have matched Regressor/Classifier variants
used directly.
"""
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from xgboost import XGBRegressor, XGBClassifier


def _pipeline(estimator, scale: bool = True):
    steps = [("impute", SimpleImputer(strategy="median"))]
    if scale:
        steps.append(("scale", StandardScaler()))
    steps.append(("model", estimator))
    return Pipeline(steps)


def get_severity_baselines(random_state: int = 42) -> dict:
    """Regression baselines for the severity (NP3TOT) target."""
    return {
        "Ridge": _pipeline(Ridge(random_state=random_state)),
        "RandomForest": _pipeline(RandomForestRegressor(n_estimators=300, random_state=random_state), scale=False),
        "XGBoost": _pipeline(XGBRegressor(n_estimators=300, random_state=random_state, verbosity=0), scale=False),
    }


def get_stage_baselines(random_state: int = 42) -> dict:
    """Classification baselines for the stage (NHY, collapsed per D016) target.
    class_weight='balanced' used where supported, given the severe class imbalance (D016) --
    without it, a classifier here would trivially default toward the majority class.
    """
    return {
        "LogisticRegression": _pipeline(
            LogisticRegression(max_iter=2000, class_weight="balanced", random_state=random_state)
        ),
        "RandomForest": _pipeline(
            RandomForestClassifier(n_estimators=300, class_weight="balanced", random_state=random_state), scale=False
        ),
        "XGBoost": _pipeline(
            XGBClassifier(n_estimators=300, random_state=random_state, verbosity=0), scale=False
        ),
    }
