# Parkinson's Disease Progression, Severity, and Stage Prediction from DaTSCAN Imaging Biomarkers (PPMI)

**Status:** Planning / raw data audit in progress
**Data source:** Parkinson's Progression Markers Initiative (PPMI) — raw exports, merged from source

## Project scope

This project predicts three distinct, clinically motivated targets from PPMI clinical and
DaTSCAN imaging biomarker data:

| Target | Definition | Status |
|---|---|---|
| **Progression** | Longitudinal change in PD severity over time | Pending data validation |
| **Stage** | Hoehn & Yahr stage (`NHY`, MDS-UPDRS Part III) | Data confirmed available |
| **Severity** | MDS-UPDRS Part III total score (`NP3TOT`), motor exam-based | Defined, see `docs/01_decision_log.md` |

Diagnosis classification (PD vs. Healthy Control / SWEDD / Prodromal) was **considered and
dropped** — the raw files available to this project do not include a cohort/diagnosis field
(e.g. `COHORT`, `Participant_Status.csv`), and inventing labels would not be scientifically
valid. See `docs/01_decision_log.md` for the full reasoning.

## Why this structure

This repository is designed to be reproducible end-to-end: from raw PPMI exports to every
figure and table in the paper. It deliberately does **not** contain any raw or processed PPMI
data — PPMI's Data Use Agreement restricts redistribution of subject-level data, so `data/` is
gitignored and this repo instead documents exactly how to obtain and regenerate it.

```
├── data/                  # gitignored — raw/processed PPMI data lives here locally only
├── src/                   # modular, reusable code (import this from notebooks, don't duplicate logic)
│   ├── data/               # loading, cleaning, merging
│   ├── features/           # feature engineering
│   ├── models/             # baseline + deep learning model definitions
│   ├── evaluation/          # metrics, statistical tests, calibration
│   └── utils/
├── notebooks/             # thin notebooks that call into src/, not large blocks of logic
├── docs/                  # roadmap, decision log, data dictionary, experiment/model/hyperparameter logs
├── experiments/logs/       # one record per experiment run (never overwritten, never lost)
├── paper/                 # LaTeX source; figures/tables are exported here by src/, not hand-pasted
└── models/                # trained model artifacts (gitignored if large; tracked via Git LFS if needed)
```

## Compute & platform strategy

- **Compute:** Kaggle (private notebook + private dataset) as primary, Google Colab as backup.
  All models here are tabular deep learning (MLP, tabular-ResNet, TabNet, FT-Transformer, SAINT,
  TabM) on a cohort in the low thousands of patients — a free-tier GPU is sufficient; no
  dedicated GPU procurement is required for the current scope.
- **Data hosting:** never public. Raw/processed PPMI data stays in private Kaggle
  datasets/local disk only.
- **Code hosting:** this GitHub repo, public, code only.

See `docs/00_project_roadmap.md` for phase-by-phase plan and `docs/01_decision_log.md` for
every methodological decision made so far, with rationale and rejected alternatives.

## Reproducing this project

1. Obtain your own PPMI data access (https://www.ppmi-info.org/access-data-specimens/download-data)
   and accept the Data Use Agreement.
2. Download the raw tables listed in `docs/03_data_dictionary.md`.
3. Place them under `data/raw/` following the folder layout documented there.
4. Install dependencies: `pip install -r requirements.txt`
5. Run the pipeline notebooks/scripts in `notebooks/` in numeric order.

## License

Code in this repository is [MIT licensed](LICENSE). **PPMI data is not included and is governed
by PPMI's own Data Use Agreement — this repository does not grant any rights to that data.**
