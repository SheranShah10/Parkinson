# hyperparameter_log

_Not yet started — this stage of the roadmap hasn't been reached. This file will be
populated during that phase rather than left as a generic placeholder; see
`00_project_roadmap.md` for phase status and `01_decision_log.md` for decisions already
made that will feed into this document._
