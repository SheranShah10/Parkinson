# Data Dictionary — Raw Source Files

Place these under `data/raw/<subfolder>/` exactly as named below. All PPMI downloads are
subject-level, so this repo never contains them — download your own copy from the PPMI portal.

| File | Rows | Unique PATNO | Key columns | Role |
|---|---|---|---|---|
| `Demographics_*.csv` | 8,069 | 8,069 | `PATNO`, `SEX`, `BIRTHDT`, race/ethnicity fields | Static covariates |
| `MDS_UPDRS_Part_II__Patient_Questionnaire_*.csv` | 34,084 | 4,877 | `PATNO`, `EVENT_ID`, `NP2PTOT` | Functional severity (secondary target) |
| `MDS-UPDRS_Part_III_*.csv` | 36,602 | 4,881 | `PATNO`, `EVENT_ID`, `INFODT`, `PDSTATE`, `NP3TOT`, `NHY` | **Primary severity (NP3TOT) & stage (NHY) source** |
| `DaTscan_Imaging_*.csv` | 13,919 | 7,052 | `PATNO`, `EVENT_ID`, `INFODT`, `DATSCAN` | Imaging visit metadata (not quantitative biomarkers) |
| `Xing_Core_Lab_-_Quant_SBR_*.csv` | 3,568 | 1,542 | `PATNO`, `EVENT_ID`, `DATSCAN_DATE`, striatal binding ratio (SBR) columns | **Quantitative DaTSCAN biomarkers — primary imaging features** |
| `FOUND_Enrollment_Status_*.csv` | 3,261 | — | `PATNO`, `FOSTATUS` | Enrollment/vital status only — not a diagnosis field |
| `Eligibility_Override_*.csv` | 237 | — | `PATNO`, `EVENT_ID` | Eligibility exceptions |

## Known data quality issues (see decision log for handling)

- `NHY` contains an out-of-range code `101` in 604 rows (D004).
- UPDRS-III has duplicate `PATNO + EVENT_ID` rows from ON/OFF medication-state exams (D005).
- Clinical (`BL/PW/R01/R04...`) and imaging (`BL/SC/ST/V02...`) tables use different visit-code
  vocabularies — do not join on `EVENT_ID` alone (D006).

## Missing from this project (blocking diagnosis prediction only)

- `Participant_Status.csv` (or equivalent) — would provide `COHORT` / `COHORT_DEFINITION`.
  Not currently available; diagnosis prediction is out of scope until/unless this is added
  (D003).

## Per-variable dictionary

To be completed feature-by-feature during the Dataset Documentation phase, following the
template: source dataset, clinical meaning, data type, units, missing %, preprocessing,
used (Y/N), justification, leakage risk. Not yet started — placeholder for that phase.
