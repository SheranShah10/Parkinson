# Experiment Log

Every run recorded here with dataset version, split, feature set, model, and results.
Full machine-readable record: `experiments/logs/baseline_run_001.json`.

---

## Run 001 — Baseline models, severity + stage, NP2PTOT ablation

- **Date:** first baseline pass, post-leakage-analysis
- **Dataset:** `imaging_anchored_features` (built via `src.features.build_features`), n=1,394 patients / 3,218 visit-rows
- **Split:** patient-level 80/20 (`src.utils.splitting.patient_level_train_test_split`, seed=42) — zero patient overlap verified
- **Feature sets tested:** `core_features` (demographics + SBR + asymmetry) vs. `core_plus_NP2PTOT` (D014 ablation)
- **Severity target:** `NP3TOT`, severity-eligible rows only (D008), n=3,006 train+test rows
- **Stage target:** `NHY`, collapsed to {0,1,2,"3+"} (D016), n=3,031 train+test rows

### Severity results (regression)

| Model | Features | MAE | RMSE | R² |
|---|---|---|---|---|
| Ridge | core | 8.53 | 10.72 | 0.197 |
| Ridge | core+NP2PTOT | 8.05 | 10.09 | **0.288** |
| RandomForest | core | 8.63 | 10.94 | 0.163 |
| RandomForest | core+NP2PTOT | 7.96 | 10.06 | **0.293** |
| XGBoost | core | 9.34 | 11.80 | 0.027 |
| XGBoost | core+NP2PTOT | 8.47 | 10.75 | 0.192 |

**NP2PTOT adds consistent, meaningful lift across every model** (R² roughly +0.09 to +0.16) —
supports keeping it as a feature (D014) rather than treating the r=0.52 correlation as
disqualifying. XGBoost underperforms Ridge/RandomForest here with default hyperparameters —
expected on a dataset this size; flagged for the Hyperparameter Optimization phase rather than
concluded to be a worse model in principle. Figure: `paper/figures/severity_baseline_r2.png`.

### Stage results (classification, 4 collapsed classes)

| Model | Features | Balanced Acc | Macro-F1 | MCC | Cohen's κ | Accuracy |
|---|---|---|---|---|---|---|
| LogisticRegression | core | 0.677 | 0.480 | 0.316 | 0.276 | 0.509 |
| LogisticRegression | core+NP2PTOT | **0.737** | **0.521** | 0.341 | 0.301 | 0.540 |
| RandomForest | core | 0.469 | 0.451 | 0.340 | 0.308 | 0.714 |
| RandomForest | core+NP2PTOT | 0.476 | 0.469 | 0.342 | 0.308 | 0.717 |
| XGBoost | core | 0.459 | 0.450 | 0.293 | 0.283 | 0.684 |
| XGBoost | core+NP2PTOT | 0.515 | 0.529 | 0.347 | **0.336** | 0.709 |

**A concrete illustration of why balanced accuracy is the primary metric, not raw accuracy
(D016/roadmap phase 7 finding):** class-weighted Logistic Regression achieves the best
balanced accuracy (0.737) but the *lowest* raw accuracy (0.540) — it actively trades majority-
class accuracy for minority-class recall. Random Forest/XGBoost show the opposite pattern
(accuracy ~0.68–0.72 by leaning on the majority class 2, balanced accuracy notably lower).
Neither pattern is "wrong" — they reflect a real precision/recall tradeoff on a severely
imbalanced target, and both numbers must be reported together in the paper, never accuracy
alone. NP2PTOT again adds consistent lift. Figure: `paper/figures/stage_baseline_balanced_accuracy.png`.

### Conclusions / carried forward
- Best severity baseline: RandomForest, core+NP2PTOT (R²=0.293) — leaves clear room for
  deep learning models to improve on.
- Best stage baseline (by balanced metrics): XGBoost, core+NP2PTOT (MCC=0.347, κ=0.336) or
  LogisticRegression (balanced accuracy=0.737) depending on which error type matters more
  clinically — worth an explicit discussion in the paper rather than picking one "winner" metric.
- XGBoost's underperformance vs. simpler models on both tasks is a hyperparameter-tuning
  question, not a conclusion about model families — carried forward to Hyperparameter
  Optimization phase.
