# Project Roadmap

Phases may reorder if the data requires it — see `01_decision_log.md` for any deviation and why.

| # | Phase | Status |
|---|---|---|
| 1 | Project planning | In progress |
| 2 | Research question validation | In progress (progression pending; stage & severity confirmed feasible; diagnosis dropped) |
| 3 | Raw data audit | In progress |
| 4 | Dataset documentation | Started (`03_data_dictionary.md`) |
| 5 | Longitudinal data integration | Started — date-tolerance merge strategy chosen |
| 6 | Target construction | Done — severity (NP3TOT, D001/D008), stage (NHY, D002/D004) |
| 7 | Exploratory Data Analysis | **Done — see `docs/05_eda_findings.md`** |
| 8 | Data cleaning | **Done — see `docs/06_preprocessing_report.md`** |
| 9 | Missing value analysis | Done for targets (D008); residual 7% handled in Data Cleaning |
| 10 | Feature engineering | **Done — see `docs/04_feature_dictionary.md` candidate feature table** |
| 11 | Feature selection | Not started |
| 12 | Leakage analysis | **Done — see `docs/04_feature_dictionary.md` leakage screen + D011/D013/D014/D015** |
| 13 | Baseline ML models | **Done — see `docs/07_experiment_log.md`, `docs/08_model_log.md`** |
| 14 | Advanced deep learning models | **Done — see `docs/08_model_log.md`; FTTransformer strongest model overall** |
| 15 | Hyperparameter optimization | Not started |
| 16 | Explainability | Not started |
| 17 | Statistical comparison | Not started |
| 18 | Error analysis | Not started |
| 19 | Ablation studies | Not started |
| 20 | Research paper preparation | Not started |
| 21 | Final GitHub repository | Skeleton created (this repo) |
| 22 | Presentation preparation | Not started |

## Current cohort snapshot (from raw audit so far)

- Demographics: 8,069 unique patients
- MDS-UPDRS Part II: 4,877 unique patients
- MDS-UPDRS Part III: 4,881 unique patients
- DaTSCAN imaging metadata: 7,052 unique patients
- Xing Core Lab Quant SBR (imaging biomarkers): 1,542 unique patients
- **Clinical-only cohort (stage + severity, no imaging):** 4,866 patients, median 4 visits/patient (max 27)
- **Imaging-anchored cohort (stage + severity + DaTSCAN together):** 1,394 patients, after
  date-tolerance visit matching (see `01_decision_log.md`, entry on merge strategy)

This is the effective ceiling on sample size for any model that uses DaTSCAN/SBR as an input.
