# Model Log

## Baseline models (implemented, `src/models/baseline.py`)

| Model | Task | Notes |
|---|---|---|
| Ridge Regression | Severity | Regression counterpart to Logistic Regression (D016) — Logistic Regression cannot target a continuous score |
| Random Forest Regressor | Severity | n_estimators=300, default depth |
| XGBoost Regressor | Severity | n_estimators=300, default hyperparameters — underperformed, flagged for tuning |
| Logistic Regression | Stage | `class_weight='balanced'`, multinomial, 4 collapsed classes (D016) |
| Random Forest Classifier | Stage | `class_weight='balanced'`, n_estimators=300 |
| XGBoost Classifier | Stage | n_estimators=300, default hyperparameters |

All models run through a `SimpleImputer(median)` + optional `StandardScaler` pipeline
(scaling applied for Ridge/LogisticRegression, skipped for tree-based models where it has no
effect). See `docs/07_experiment_log.md` for results.

## Deep learning models (implemented, `src/models/deep_learning.py`, `src/models/train_deep.py`)

| Model | Implementation status |
|---|---|
| MLP | Standard, faithful |
| Tabular ResNet | Standard, faithful (Gorishniy et al. style) |
| FT-Transformer | Implemented from scratch (feature tokenizer + transformer + CLS), faithful to the core architecture |
| TabNet | Implemented via `pytorch-tabnet` (real library, faithful) |
| SAINT (simplified) | Feature-attention + intersample-attention implemented; contrastive pretraining stage **omitted**. Report as "SAINT (simplified)", not SAINT. |
| TabM (simplified) | BatchEnsemble-style shared-weight MLP ensemble implemented; not verified against the official repo's exact parameterization. Report as "TabM (simplified reimplementation)". |

### Complete comparison — all 9 models, core+NP2PTOT features (best feature set)

**Severity (R², ranked):** FTTransformer 0.361 · SAINT_simplified 0.350 · TabularResNet 0.319 ·
RandomForest 0.293 · MLP 0.291 · Ridge 0.288 · TabM_simplified 0.285 · TabNet 0.254 ·
XGBoost 0.192

**Stage (balanced accuracy, ranked):** LogisticRegression 0.737 · FTTransformer 0.732 ·
TabM_simplified 0.722 · SAINT_simplified 0.698 · MLP 0.695 · TabularResNet 0.681 ·
TabNet 0.639 · XGBoost 0.515 · RandomForest 0.476

Figures: `paper/figures/severity_all_models_comparison.png`,
`paper/figures/stage_all_models_comparison.png` (sorted by performance, post-D017-fix numbers).

**FT-Transformer is the strongest model overall**, with **SAINT-simplified now a close second**
after the D017 fix — both clearly ahead of every baseline on severity, and within a few points
of class-weighted Logistic Regression on stage. The four attention/deep architectures
(FTTransformer, SAINT, TabM, MLP) form a clear top tier on stage; the two gradient-boosting
baselines (XGBoost, RandomForest) trail noticeably on balanced accuracy specifically, despite
XGBoost being competitive on raw accuracy in `docs/07_experiment_log.md` — another illustration
of why balanced metrics, not raw accuracy, drive the actual ranking here.

The D017 fix is worth stating plainly in the paper's methodology or discussion: a
missing-residual bug initially looked like "SAINT can't learn this data," and only architectural
inspection (not more tuning or more epochs) revealed the actual cause.




