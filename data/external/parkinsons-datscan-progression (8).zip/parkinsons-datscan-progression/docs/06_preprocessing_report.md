# Preprocessing Report — Data Cleaning Phase

## Range validation (guard-rail check)
`NP3TOT`, `NP2PTOT`, `NHY` all validated against their theoretical scale bounds
(0-132, 0-52, 0-5 respectively) on the full clinical-only cohort (30,296 rows):
**zero violations found.** No data-entry range errors in these three columns.

## SBR anomaly flags (see D009 for full reasoning)
Applied to the imaging-anchored cohort (3,218 rows) via `src.data.cleaning.flag_sbr_anomalies`:

| Column | Negative-value flag | Extreme outlier flag (3x IQR) |
|---|---|---|
| STRIATUM_REF_CWM | 2 | 9 |
| STRIATUM_L_REF_CWM | 3 | — |
| STRIATUM_R_REF_CWM | 1 | — |
| PUTAMEN_REF_CWM | 1 | 34 |
| PUTAMEN_L_REF_CWM | 2 | — |
| CAUDATE_REF_CWM | 11 | 0 |

No row is flagged on both negative-value AND extreme-outlier for the same column (checked for
STRIATUM_REF_CWM: 0 overlap) — these are catching different things, not double-counting the
same anomalous rows.

**Nothing was dropped or clipped.** Flags are additive boolean columns; any exclusion decision
is deferred to individual modeling experiments and must be logged in `07_experiment_log.md`
when it happens, not silently baked into the shared pipeline.

## Posterior-caudate sub-region negatives — expected, not flagged
Sub-region columns like `POSCAUDATE_R_REF_CWM` go negative in up to 137 of 3,218 rows. This is
expected behavior for a naturally low-signal reference sub-region in DAT-SPECT quantification
(background-subtraction noise around near-zero true signal), not a data-quality problem, and is
therefore not flagged the way the composite regions are. See D009 for the distinction.

## Categorical / dtype sanity checks
- `SEX`: {0, 1, NaN} — clean, no stray codes
- `PDSTATE`: {NaN, 'ON', 'OFF'} — clean
- `DATSCAN_ANALYZED`: {'Yes', 'No'} — clean
- `PATNO`: int64 throughout — clean
- No duplicate `REC_ID` in Demographics

## Status
Data Cleaning phase substantively complete for the columns currently load-bearing (severity,
stage, core SBR biomarkers). Will revisit if Feature Engineering pulls in additional raw
columns not yet checked here.
