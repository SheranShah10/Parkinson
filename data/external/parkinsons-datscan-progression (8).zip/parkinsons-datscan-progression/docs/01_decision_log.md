# Decision Log

Every entry: **What / Why / Alternatives considered / Why rejected / Evidence**

---

### D001 — Severity target = MDS-UPDRS Part III total (`NP3TOT`)
- **What:** Severity is operationalized as the exam-based motor score, `NP3TOT`.
- **Why:** Matches field convention in published DaTSCAN-severity literature; rater-assessed
  (not self-reported, unlike `NP2PTOT`); keeps DaTSCAN/SBR cleanly on the input side for every
  task, avoiding target-input circularity.
- **Alternatives considered:** `NP2PTOT` (functional/self-report severity); combined
  NP2+NP3; SBR-derived imaging severity.
- **Why rejected:** NP2PTOT is patient-reported and noisier as a ground truth. SBR-derived
  severity would make the target partly a restatement of the model's own input feature set —
  a leakage risk, not a modeling choice.
- **Status:** NP2PTOT and NP2+NP3 kept as documented secondary/sensitivity targets, not primary.

### D002 — Stage target = Hoehn & Yahr (`NHY`)
- **What:** Stage prediction uses `NHY` from MDS-UPDRS Part III directly — a validated ordinal
  clinical staging scale (0–5).
- **Why:** It is the standard, no derivation needed.
- **Evidence:** Present in `MDS-UPDRS_Part_III` for the full cohort with visit-level records.

### D003 — Diagnosis prediction dropped from scope
- **What:** Diagnosis classification (PD / Healthy Control / SWEDD / Prodromal, etc.) is out
  of scope for this project.
- **Why rejected:** None of the raw files provided (Demographics, DaTSCAN imaging metadata,
  MDS-UPDRS II/III, Xing Core Lab SBR, FOUND Enrollment Status, Eligibility Override) contain
  a cohort/diagnosis field (e.g. `COHORT`, `COHORT_DEFINITION`). All patients present appear to
  already be enrolled in a DaTSCAN-related arm. Modeling diagnosis without this field would
  mean inventing labels, which is not scientifically valid.
- **Path to revisit:** If `Participant_Status.csv` (or equivalent PPMI core file with cohort
  labels) is obtained later, this can be reconsidered as an added task.

### D004 — `NHY = 101` treated as missing/invalid, not a valid stage
- **What:** 604 of 36,602 UPDRS-III rows have `NHY = 101`, outside the valid 0–5 range.
- **Evidence:** Checked for correlation with medication state (`PDSTATE`) in case it was a
  compound on/off code — no clean pattern (51 OFF, 270 ON, 283 blank), so it does not appear
  to be a meaningful modifier.
- **Why:** With no verified explanation, treating an out-of-range code as a guessed value
  would be worse than treating it as missing.
- **Action:** Rows with `NHY = 101` are excluded from stage modeling; the underlying visit
  still contributes to severity modeling if `NP3TOT` is present. To be re-checked against the
  official PPMI data dictionary if/when accessible.

### D005 — UPDRS-III ON/OFF duplicate visits: OFF-state is canonical
- **What:** Some `PATNO + EVENT_ID` combinations in UPDRS-III have two rows (ON and OFF
  medication state exams logged under the same visit code).
- **Why:** OFF-state reflects underlying disease severity; ON-state reflects medication
  effect. For a disease-severity/stage modeling target, OFF-state is the field-standard choice.
- **Evidence:** Direct-key matching produced more matched rows (3,684) than SBR source rows
  (3,568), indicating duplicate visit-keys in UPDRS-III.
- **Action:** When both states exist for a visit, OFF-state record is used as canonical;
  ON-state is retained in a secondary column for sensitivity analysis, not discarded.

### D006 — Clinical–imaging merge by date proximity, not by `EVENT_ID`
- **What:** SBR (imaging) records are linked to clinical (UPDRS) records by nearest visit date
  within a ±90 day tolerance window, per patient — not by matching `EVENT_ID` strings.
- **Why:** Clinical and imaging tables use different visit-code vocabularies (clinical:
  BL/PW/R01/R04...; imaging: BL/SC/ST/V02...). Matching on `EVENT_ID` directly recovered only
  1,126 of 1,484 patients known to have both records (76%); date-tolerance matching recovered
  1,394 (94%).
- **To do:** Sensitivity-test the 90-day window (e.g. 30/60/90/180 days) once we're in the
  longitudinal integration phase, and report how cohort size changes with window width.

### D007 — Compute & hosting strategy
- **What:** Kaggle (private notebook + private dataset) as primary compute, Colab as backup;
  no dedicated GPU procurement; GitHub public repo for code only, PPMI data never committed.
- **Why:** All planned models are tabular deep learning (not raw-image CNNs) on a cohort in
  the low thousands — free-tier GPU is sufficient. PPMI's Data Use Agreement restricts
  redistribution of subject-level data, so public hosting of data (e.g. a public Kaggle
  dataset) is avoided by default regardless of the exact DUA text, which has not yet been
  independently verified.
- **Open item:** Confirm the exact PPMI DUA redistribution clause when convenient; current
  setup is deliberately conservative and shouldn't need to change even if the DUA turns out to
  be more permissive.

### D008 — Remote (telehealth) visits excluded from severity-target modeling
- **What:** Rows from `R`-prefixed visits (`R01, R04, R06...`) are flagged
  `severity_target_eligible = False` and excluded from `NP3TOT` modeling, kept for other uses.
- **Why:** `NP3TOT` is missing in 91.9% of remote visits vs. 0.4-1.6% at in-person visit types
  (SC/BL/ST), because the motor exam (rigidity, finger-tapping) requires physical contact that
  cannot be performed over video. This is structural missingness tied to visit modality, not a
  random gap — imputing it would fabricate exam results that were never physically possible to
  collect.
- **Evidence:** Missingness by visit-type prefix: SC 0.4%, BL 1.6%, ST 0.5%, V 8.8%, R 91.9%.
  Supporting signals: `OFFEXAM=0` (exam not performed) predicts 99.9% missingness;
  `DBSYN=1` (deep brain stimulation patients, different exam protocol) shows elevated
  missingness (53.8%) for a separate, protocol-driven reason.
- **Effect:** After exclusion, residual `NP3TOT` missingness in the eligible rows drops from
  18.57% to **7.05%** — confirms the mechanism, and leaves a much smaller, more standard
  missing-value problem for the Missing Value Analysis phase.
- **Note on stage (`NHY`):** Remote visits are missing `NHY` far less often (22.2%) than
  `NP3TOT` (91.9%) at the same visits, since Hoehn & Yahr can partly be judged by observing
  gait/posture on video. Remote visits are therefore **not** excluded from stage modeling by
  default — to be revisited if EDA suggests otherwise.
- **Imaging-anchored cohort impact:** Negligible — only 5 of 3,218 imaging-anchored rows are
  remote visits, since DaTSCAN appointments are inherently in-person.

### D009 — SBR anomalies flagged, not dropped or clipped
- **What:** Two categories flagged as boolean columns rather than removed: (1) negative values
  in composite SBR regions (STRIATUM/PUTAMEN/CAUDATE, both hemispheres) — clinically implausible
  since these are dominated by real signal even in severe disease; (2) extreme outliers via a
  wide 3x-IQR fence (not the usual 1.5x) on the three primary composite columns.
- **Why flag instead of remove:** Range validation confirmed `NP3TOT`, `NP2PTOT`, `NHY` all sit
  within their theoretical valid bounds — no data-entry errors there. For SBR, only **2 rows**
  have a negative composite `STRIATUM_REF_CWM` value (both mild/moderate-stage patients, not
  end-stage — an unusual but not impossible combination given the imaging-clinical correlation
  is moderate, not perfect, per EDA). Dropping 2 otherwise-complete patients on a borderline
  value isn't justified. The wide 3x-IQR fence (34 flagged for PUTAMEN, 9 for STRIATUM, 0 for
  CAUDATE) deliberately avoids flagging genuine severe-disease cases as "errors" — those are
  exactly the cases later error-analysis and ablation work need intact, not removed.
- **Important distinction found during this pass:** posterior-caudate *sub-region* columns
  (`POSCAUDATE_R_REF_CWM`, etc.) go negative far more often (up to 137 rows) than the composite
  regions. This is expected — posterior caudate is a naturally low-signal reference sub-region
  in DAT-SPECT quantification, so small negative values there reflect background-subtraction
  noise around a near-zero true signal, not a data-quality problem. These sub-region columns
  are therefore **not** flagged the same way as the composite columns; documented here so it
  isn't mistaken for a systematic imaging-data error later.
- **Action:** `src.data.cleaning.flag_sbr_anomalies` adds `{col}_negative_flag` and
  `{col}_extreme_outlier_flag` boolean columns to the imaging-anchored master table. No rows
  removed. Modeling code should decide per-experiment whether to exclude flagged rows, and log
  that choice in the experiment log — not bake exclusion into the shared data pipeline.

### D010 — Asymmetry Index uses a relative (per-region) stability floor, not a fixed one
- **What:** `src.features.build_features.compute_asymmetry_features` computes a standard
  DAT-SPECT Asymmetry Index (AI = (R-L)/(R+L)×100) for STRIATUM, PUTAMEN, CAUDATE. Rows where
  |L+R| falls below 25% of that region's own median (L+R) are set to NaN and flagged
  `{region}_AI_unstable_flag`, rather than left as a computed value.
- **Why:** Initial computation produced AI values up to ±1700% — numerically real (the
  denominator was near-zero for near-total dopaminergic depletion cases) but not meaningful as
  an "asymmetry percentage." A fixed absolute cutoff doesn't generalize since STRIATUM, PUTAMEN,
  and CAUDATE have different natural SBR scales — a relative (scale-aware) floor was used
  instead. This left 38/3187 (STRIATUM), 28/3187 (PUTAMEN), 90/3186 (CAUDATE) rows flagged
  unstable rather than silently producing extreme values.
- **Mitigation:** `{region}_diff` (raw R−L, no division) is always computed alongside AI as a
  stable alternative that doesn't share this failure mode — available for modeling even on
  rows where AI itself is unstable.
- **Note:** `STRIATUM_AI_abs` correlates only weakly with severity (r=0.12) — clinically
  plausible, not concerning: PD asymmetry is understood to often *decrease* as disease becomes
  more bilateral with progression, so asymmetry magnitude isn't expected to track overall
  severity linearly.

### D011 — `NP3TOT_ON_secondary` excluded from severity-prediction feature set
- **What:** The ON-medication-state motor score (`NP3TOT_ON_secondary`, preserved per D005)
  will **not** be used as a model input feature for predicting severity (`NP3TOT`, OFF-state).
- **Why:** Correlation between `NP3TOT_ON_secondary` and the OFF-state target is **r=0.824**
  (n=1,280) — both measure closely related motor severity constructs at nearly the same visit.
  Using it as a feature would let a model largely reconstruct the answer from a near-duplicate
  measurement rather than learning from imaging/demographic signal, and it isn't something
  available at prediction time in the clinical scenario this project targets (predicting
  severity from imaging biomarkers, not from an ON-state exam that already required doing the
  assessment). This is the first entry in what should become the project's formal Leakage
  Analysis phase, not a one-off aside.
- **Status:** Retained in the processed table for sensitivity analysis / error analysis only,
  explicitly excluded from the candidate feature set.

### D012 — Cohort diversity limitation, noted not corrected
- **What:** The imaging-anchored cohort is 94.6% White (1,319/1,394, from `RAWHITE`) and 87.7%
  right-handed. Consistent with PPMI's cohort composition generally.
- **Why noted, not "fixed":** This is a genuine generalizability limitation for the paper's
  Limitations section — no cleaning or reweighting step can manufacture diversity that isn't in
  the source data, and pretending otherwise would misrepresent the cohort.

### D013 — All train/test splits and cross-validation must be patient-level, not row-level
- **What:** 927 of 1,394 patients (66.5%) in the imaging-anchored cohort have more than one
  visit-record. Any row-level random split risks the same patient appearing in both train and
  test sets.
- **Why this matters:** A model could partly learn to recognize "this specific patient's"
  imaging signature rather than generalizable severity/stage signal, inflating apparent
  performance in a way that won't hold on genuinely unseen patients — a well-known failure mode
  in longitudinal medical ML that reviewers specifically look for.
- **Action:** `src.utils.splitting.patient_level_train_test_split` and `patient_group_kfold`
  implement group-aware splitting (via sklearn's `GroupShuffleSplit`/`GroupKFold`, grouped on
  `PATNO`). Verified: zero patient overlap between resulting train/test sets. **All modeling
  code must use these, not sklearn's default row-level splitters, for both the main split and
  any cross-validation.**

### D014 — `NP2PTOT` retained as a feature, flagged for a sensitivity check (not excluded like D011)
- **What:** Fixed a pipeline gap where `NP2PTOT` (functional/patient-reported severity) was
  documented as available for the imaging-anchored cohort but had never actually been merged
  in — now wired into `build_master_table`. Its correlation with the severity target
  (`NP3TOT`) is **r=0.517** (n=2,999) and with stage (`NHY`) is ρ=0.445 (n=3,022).
- **Why this is different from D011:** `NP2PTOT` (patient questionnaire, functional impact)
  and `NP3TOT` (clinician motor exam) are genuinely distinct constructs that happen to
  correlate because they both reflect the same underlying disease process — this is exactly
  why the combined MDS-UPDRS II+III score is standard practice in the PD literature, unlike
  `NP3TOT_ON_secondary` (D011, r=0.824), which is a near-duplicate measurement of the *same*
  construct at nearly the same time.
- **Decision:** Retain `NP2PTOT` as a candidate feature (not excluded), but flag it for a
  mandatory ablation/sensitivity check during modeling — train with and without it and report
  the difference, so its contribution is transparent rather than assumed.

### D015 — Explicit feature-matrix exclusion list (identifiers, admin/QC columns)
The following are never model input features, regardless of any correlation they might show:
`PATNO`, `REC_ID`, `EVENT_ID` / `clinical_EVENT_ID` (identifiers); `INFODT`, `DATSCAN_DATE`
(raw calendar dates — arbitrary and potentially confounded with PPMI protocol changes over its
~15-year enrollment window; use `AGE_AT_VISIT` instead); `match_delta_days`,
`visit_had_on_off_duplicate`, `NHY_invalid_raw`, `PDSTATE_norm` (pipeline QC/administrative
artifacts, not clinical signal); `NP3TOT_ON_secondary` (D011). This list lives here and should
be kept in sync with `src/features/build_features.py` as the feature set evolves.

### D016 — Stage classes collapsed to {0, 1, 2, "3+"} for baseline modeling
- **What:** `NHY` stages 3, 4, 5 (73, 10, 1 patients respectively — see EDA) are collapsed
  into a single "3+" class for classification. Full-resolution stage is preserved in the data;
  this collapse applies only at the modeling step.
- **Why:** With a patient-level 80/20 split, stage 4 (10 total) and stage 5 (1 total) would
  have at most 1-2 test examples each — not enough to compute a meaningful per-class metric,
  let alone train on. Collapsing to 4 classes (7.3%/24.1%/65.9%/2.8%) keeps every class
  computable while preserving the clinically important distinction between mild-to-moderate
  and advanced disease.
- **Also decided:** Logistic Regression is a classification algorithm and cannot target a
  continuous score — Ridge Regression is used as its counterpart for the severity task instead
  of forcing a classifier onto a regression target.

### D017 — SAINT (simplified) training collapse: root cause found and fixed, not just described
- **What:** `SAINTSimplified` initially collapsed to predicting a constant value (verified via
  near-zero prediction variance) in all four task/feature-set combinations.
- **Root cause (found, not just hypothesized):** the intersample-attention layer had no
  residual connection or LayerNorm around it, unlike the feature-attention layers (which get
  both for free from `nn.TransformerEncoderLayer`). This asymmetry meant every intersample
  attention pass could freely discard the incoming representation instead of refining it,
  and stacking multiple such layers compounded into full representation collapse. Confirmed
  by direct test: lowering the learning rate and adding warmup alone did **not** fix it
  (R² actually got worse, down to -1.69), which ruled out "just an optimization/LR issue" and
  pointed at the architecture itself.
- **Fix:** added a residual connection + `LayerNorm` around the intersample-attention block,
  matching standard transformer block design. Verified immediately: R² went from ~0.000 to
  0.274 in a single test run.
- **Result after fix, full re-run:** severity R²=0.263 (core) / 0.350 (core+NP2PTOT) — now
  competitive with FT-Transformer (0.361) rather than failing. Stage balanced accuracy
  0.666 (core) / 0.698 (core+NP2PTOT) — also now competitive. Full comparison table updated
  in `docs/08_model_log.md`.
- **Lesson for the model log:** this is a good illustration of why "the model doesn't train"
  should prompt an architecture-level check (residuals, normalization placement) before being
  written off as a dataset-size or tuning problem — worth a sentence in the paper's methods or
  discussion section as a genuine engineering finding, not just a footnote.

### D018 — Compute note: this pass ran in a CPU sandbox, not on the project's actual Kaggle/Colab GPU setup
- **What:** All deep learning results in this pass (`experiments/logs/deep_learning_run_001.json`)
  were produced in a CPU-only development sandbox with a reduced epoch budget (40 epochs,
  patience 8) chosen to fit that environment's time constraints, not for scientific reasons.
- **Why this matters:** FTTransformer and SAINT (attention-based) took roughly 2.3-2.8
  seconds/epoch here; on the free Kaggle/Colab GPU this project is set up to use (D007), the
  same runs would be substantially faster, allowing a larger epoch budget, proper learning-rate
  scheduling, and likely resolving or clarifying the D017 SAINT issue.
- **Action:** treat this run as a first-pass, directionally informative comparison — re-run on
  GPU with a full epoch budget before treating these exact numbers as final for the paper.
