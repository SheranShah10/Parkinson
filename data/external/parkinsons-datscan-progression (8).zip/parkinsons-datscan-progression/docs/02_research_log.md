# Research Log

Running narrative of what was explored, in date order. Decisions with rationale live in
`01_decision_log.md`; this log is the informal "what we tried and noticed" trail.

---

## Entry 1 — Raw file inventory
Confirmed four raw exports available: Demographics, DaTSCAN Imaging (metadata), MDS-UPDRS
Part II, MDS-UPDRS Part III, Xing Core Lab Quant SBR, plus FOUND Enrollment Status and
Eligibility Override. No cohort/diagnosis file present (see D003).

## Entry 2 — Stage and severity feasibility check
Confirmed `NHY` (stage) and `NP3TOT` (severity candidate) both present in UPDRS-III with good
coverage (29,857 rows have both simultaneously, across 4,866 patients).

## Entry 3 — Imaging–clinical linkage test
Direct `EVENT_ID` join vs. date-tolerance join compared explicitly — date-tolerance strategy
adopted (D006). See decision log for the exact numbers.

## Entry 4 — NHY anomaly investigation
604 rows with `NHY = 101` investigated against `PDSTATE`; no clean explanation found; treated
as missing per D004.

## Next planned entry
Build the merged patient-visit master table (Demographics + UPDRS-II + UPDRS-III + SBR) and
report full missingness/coverage profile before starting EDA.
