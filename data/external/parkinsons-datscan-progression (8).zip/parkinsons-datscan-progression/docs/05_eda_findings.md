# EDA Findings — Imaging-Anchored Cohort (n=1,394 patients / 3,218 visit-records)

All figures referenced here are in `paper/figures/`, generated directly from
`src/data/merge.build_master_table` output — regenerate by re-running the pipeline, don't
hand-edit these numbers.

## 1. Severity (NP3TOT) distribution
- n=3,006 non-missing (of 3,213 severity-eligible rows; see D008)
- Mean 23.2, median 22, SD 12.5, range 0–80
- Skew 0.38 — mild right skew, not severe enough to require a transform by default; will
  re-check after outlier/error-checking in the Data Cleaning phase
- Figure: `np3tot_distribution.png`

## 2. Stage (NHY) distribution — severe class imbalance, flagged for modeling
| Stage | % of cohort |
|---|---|
| 0 | 7.29% |
| 1 | 24.08% |
| 2 | 65.85% |
| 3 | 2.41% |
| 4 | 0.33% |
| 5 | 0.03% |

Stage 2 alone accounts for two-thirds of all records; stages 3–5 combined are **2.8%** of the
cohort. A standard multiclass classifier trained on this directly will default to predicting
stage 2 and look falsely "accurate." This must shape the modeling plan (already anticipated in
the original evaluation plan's balanced accuracy / MCC / Cohen's kappa choices, but worth
restating here explicitly):
- Report macro-averaged / balanced metrics, never raw accuracy, as primary metrics
- Consider whether stages 3–5 should be modeled as a collapsed "moderate-severe" class given
  how few examples exist, or handled with class-weighting/ordinal-regression approaches instead
  of naive multiclass classification — decision deferred to the modeling phase, flagged now so
  it isn't a surprise later
- Figure: `nhy_distribution.png`

## 3. SBR (DaTSCAN biomarker) distributions
- `STRIATUM_REF_CWM`: mean 0.75, median 0.72, SD 0.30, range −0.08 to 2.15
- Left/right striatal correlation: r=0.78 — meaningfully correlated but not identical,
  consistent with PD's well-documented asymmetric onset. This is a *confirmatory* data-quality
  signal, not a problem.
- **2 rows** have a slightly negative `STRIATUM_REF_CWM` (−0.04, −0.08) — both from patients at
  mild-to-moderate stage (NHY 1–2), not end-stage, so this looks like measurement/quantification
  noise rather than a systematic issue. Negligible (2/3,218 rows); logged here rather than
  silently dropped.
- Figure: `sbr_biomarker_distributions.png`

## 4. Core clinical hypothesis check: does SBR relate to severity/stage?
This is the hypothesis the whole project rests on, so it's worth checking directly and early
rather than assuming it during modeling:
- **SBR vs. severity (NP3TOT):** Pearson r = **−0.446** (p=2.1×10⁻¹⁴⁵, n=2,975) — lower striatal
  binding (worse dopaminergic deficit) associates with higher motor severity, as expected
  clinically.
- **SBR vs. stage (NHY):** Spearman ρ = **−0.386** (p=3.8×10⁻¹⁰⁷, n=3,000) — same direction,
  ordinal-appropriate correlation.
- **Interpretation:** the relationship is real and highly significant, but only moderate in
  strength (r≈−0.45, not −0.8+). This is actually a useful, honest framing for the paper: it
  justifies *why* a multi-modal model (imaging + clinical + demographic features) should
  outperform an SBR-only baseline, rather than assuming DaTSCAN alone trivially predicts
  severity/stage.
- Figures: `sbr_vs_severity.png`, `sbr_by_stage.png`

## 5. Demographics
- Sex distribution (coded `SEX`): 861 vs. 533 (~62%/38% split) — not balanced but not extreme.
  Coding (0/1 → which sex) to be confirmed against the PPMI data dictionary before use as a
  model feature or reported in the paper.

## 6. Longitudinal depth — direct answer to the original progression-feasibility question
- Mean 2.31 imaging-linked visits per patient, median 2, max 6
- **927 of 1,394 patients (66.5%) have ≥2 imaging-linked visits** — meaning true longitudinal
  progression modeling (not just cross-sectional severity/stage) is feasible for roughly
  two-thirds of the imaging-anchored cohort. The remaining third with only 1 visit can still
  contribute to cross-sectional severity/stage tasks, just not progression.
- Max depth of 6 visits constrains how far out progression can be meaningfully predicted —
  worth stating as a limitation rather than overreaching in the paper's claims.
- Figure: `visits_per_patient.png`

## Immediate implications for next phases
1. **Data Cleaning:** address the 2 negative-SBR rows explicitly (flag, don't silently fix).
2. **Feature engineering / modeling:** stage-class imbalance (point 2) must be designed for
   from the start, not discovered after a misleadingly high-accuracy first model.
3. **Progression scope:** confirmed feasible for the ~927-patient longitudinal subset; this
   should be documented as the actual progression-task cohort size going forward.
