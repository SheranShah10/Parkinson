import sys, json, datetime
sys.path.insert(0, "parkinsons-datscan-progression")
import pandas as pd
import numpy as np

from src.data.loaders import load_demographics, load_updrs_ii, load_updrs_iii, load_sbr
from src.data.merge import build_master_table
from src.data.cleaning import flag_sbr_anomalies
from src.features.build_features import build_candidate_features
from src.utils.splitting import patient_level_train_test_split
from src.models.baseline import get_severity_baselines, get_stage_baselines
from src.evaluation.metrics import regression_metrics, classification_metrics

u3 = load_updrs_iii(path="csvs/fyp/MDS-UPDRS_Part_III_14Feb2026.csv")
sbr = load_sbr(path="csvs/fyp/Xing_Core_Lab_-_Quant_SBR_14Feb2026.csv")
demo = load_demographics(path="csvs/fyp/Demographics_14Feb2026.csv")
u2 = load_updrs_ii(path="csvs/fyp/MDS_UPDRS_Part_II__Patient_Questionnaire_14Feb2026.csv")

tables = build_master_table(demo, u2, u3, sbr, tolerance_days=90)
img = flag_sbr_anomalies(tables["imaging_anchored"])
feat = build_candidate_features(demo, img)

# D016: collapse rare NHY stages 3/4/5 into a single "3+" bucket for viable classification
feat["NHY_grouped"] = feat["clinical_NHY"].map(lambda x: "3+" if pd.notna(x) and x>=3 else (str(int(x)) if pd.notna(x) else np.nan))
print("NHY_grouped distribution:\n", feat["NHY_grouped"].value_counts(dropna=False))
label_map = {"0": 0, "1": 1, "2": 2, "3+": 3}
inv_label_map = {v: k for k, v in label_map.items()}
feat["NHY_grouped_encoded"] = feat["NHY_grouped"].map(label_map)

CORE_FEATURES = [
    "AGE_AT_VISIT","SEX","HANDED",
    "STRIATUM_REF_CWM","PUTAMEN_REF_CWM","CAUDATE_REF_CWM",
    "STRIATUM_L_REF_CWM","STRIATUM_R_REF_CWM","PUTAMEN_L_REF_CWM","PUTAMEN_R_REF_CWM",
    "CAUDATE_L_REF_CWM","CAUDATE_R_REF_CWM",
    "STRIATUM_diff","PUTAMEN_diff","CAUDATE_diff",
    "STRIATUM_AI","PUTAMEN_AI","CAUDATE_AI",
]
WITH_NP2 = CORE_FEATURES + ["clinical_NP2PTOT"]

results = {"generated_at": datetime.datetime.now().isoformat(), "severity": {}, "stage": {}}

# ---- SEVERITY (regression), severity_target_eligible rows only (D008) ----
sev_df = feat[feat["clinical_severity_target_eligible"] & feat["clinical_NP3TOT"].notna()].copy()
train, test = patient_level_train_test_split(sev_df, test_size=0.2, random_state=42)
print(f"\nSeverity task: train={len(train)} ({train.PATNO.nunique()} pts), test={len(test)} ({test.PATNO.nunique()} pts)")

for feature_set_name, cols in [("core_features", CORE_FEATURES), ("core_plus_NP2PTOT", WITH_NP2)]:
    Xtr, ytr = train[cols], train["clinical_NP3TOT"]
    Xte, yte = test[cols], test["clinical_NP3TOT"]
    results["severity"][feature_set_name] = {}
    for name, model in get_severity_baselines().items():
        model.fit(Xtr, ytr)
        preds = model.predict(Xte)
        m = regression_metrics(yte, preds)
        results["severity"][feature_set_name][name] = m
        print(f"[severity/{feature_set_name}] {name}: MAE={m['MAE']:.2f} RMSE={m['RMSE']:.2f} R2={m['R2']:.3f}")

# ---- STAGE (classification, grouped per D016) ----
stage_df = feat[feat["NHY_grouped_encoded"].notna()].copy()
train_s, test_s = patient_level_train_test_split(stage_df, test_size=0.2, random_state=42)
print(f"\nStage task: train={len(train_s)} ({train_s.PATNO.nunique()} pts), test={len(test_s)} ({test_s.PATNO.nunique()} pts)")
print("Train class distribution:\n", train_s["NHY_grouped_encoded"].value_counts())
print("Test class distribution:\n", test_s["NHY_grouped_encoded"].value_counts())

for feature_set_name, cols in [("core_features", CORE_FEATURES), ("core_plus_NP2PTOT", WITH_NP2)]:
    Xtr, ytr = train_s[cols], train_s["NHY_grouped_encoded"]
    Xte, yte = test_s[cols], test_s["NHY_grouped_encoded"]
    results["stage"][feature_set_name] = {}
    for name, model in get_stage_baselines().items():
        model.fit(Xtr, ytr)
        preds = model.predict(Xte)
        m = classification_metrics(yte, preds)
        results["stage"][feature_set_name][name] = {k:v for k,v in m.items() if k not in ("per_class_report",)}
        print(f"[stage/{feature_set_name}] {name}: bal_acc={m['balanced_accuracy']:.3f} macro_f1={m['macro_f1']:.3f} MCC={m['MCC']:.3f} kappa={m['cohen_kappa']:.3f} (acc={m['accuracy']:.3f})")

with open("experiments/logs/baseline_run_001.json", "w") as f:
    json.dump(results, f, indent=2, default=str)
print("\nsaved experiment log.")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# Figures for the paper
fig, ax = plt.subplots(figsize=(6,4))
models = list(results["severity"]["core_features"].keys())
core_r2 = [results["severity"]["core_features"][m]["R2"] for m in models]
np2_r2 = [results["severity"]["core_plus_NP2PTOT"][m]["R2"] for m in models]
x = np.arange(len(models)); w=0.35
ax.bar(x-w/2, core_r2, w, label="Core features")
ax.bar(x+w/2, np2_r2, w, label="Core + NP2PTOT")
ax.set_xticks(x); ax.set_xticklabels(models)
ax.set_ylabel("R²"); ax.set_title("Severity baselines: R² (higher better)")
ax.legend()
plt.tight_layout()
plt.savefig("paper/figures/severity_baseline_r2.png", dpi=150)
plt.close()

fig, ax = plt.subplots(figsize=(6,4))
stage_models = list(results["stage"]["core_features"].keys())
bal_acc_core = [results["stage"]["core_features"][m]["balanced_accuracy"] for m in stage_models]
bal_acc_np2 = [results["stage"]["core_plus_NP2PTOT"][m]["balanced_accuracy"] for m in stage_models]
x2 = np.arange(len(stage_models))
ax.bar(x2-w/2, bal_acc_core, w, label="Core features")
ax.bar(x2+w/2, bal_acc_np2, w, label="Core + NP2PTOT")
ax.set_xticks(x2); ax.set_xticklabels(stage_models)
ax.set_ylabel("Balanced accuracy"); ax.set_title("Stage baselines: Balanced accuracy (higher better)")
ax.legend()
plt.tight_layout()
plt.savefig("paper/figures/stage_baseline_balanced_accuracy.png", dpi=150)
plt.close()
print("figures saved")
