import sys, json, os, datetime
sys.path.insert(0, "parkinsons-datscan-progression")
import numpy as np
import pandas as pd
from sklearn.utils.class_weight import compute_class_weight

from src.data.loaders import load_demographics, load_updrs_ii, load_updrs_iii, load_sbr
from src.data.merge import build_master_table
from src.data.cleaning import flag_sbr_anomalies
from src.features.build_features import build_candidate_features
from src.utils.splitting import patient_level_train_test_split
from src.evaluation.metrics import regression_metrics, classification_metrics
from src.models.deep_learning import MLP, TabularResNet, FTTransformer, SAINTSimplified, TabMSimplified
from src.models.train_deep import train_deep_model

TASK = sys.argv[1]          # "severity" or "stage"
FSET = sys.argv[2]          # "core_features" or "core_plus_NP2PTOT"
RESULTS_PATH = "experiments/logs/deep_learning_run_001.json"

u3 = load_updrs_iii(path="csvs/fyp/MDS-UPDRS_Part_III_14Feb2026.csv")
sbr = load_sbr(path="csvs/fyp/Xing_Core_Lab_-_Quant_SBR_14Feb2026.csv")
demo = load_demographics(path="csvs/fyp/Demographics_14Feb2026.csv")
u2 = load_updrs_ii(path="csvs/fyp/MDS_UPDRS_Part_II__Patient_Questionnaire_14Feb2026.csv")
tables = build_master_table(demo, u2, u3, sbr, tolerance_days=90)
img = flag_sbr_anomalies(tables["imaging_anchored"])
feat = build_candidate_features(demo, img)

feat["NHY_grouped"] = feat["clinical_NHY"].map(lambda x: "3+" if pd.notna(x) and x >= 3 else (str(int(x)) if pd.notna(x) else np.nan))
label_map = {"0": 0, "1": 1, "2": 2, "3+": 3}
feat["NHY_grouped_encoded"] = feat["NHY_grouped"].map(label_map)

CORE_FEATURES = [
    "AGE_AT_VISIT", "SEX", "HANDED",
    "STRIATUM_REF_CWM", "PUTAMEN_REF_CWM", "CAUDATE_REF_CWM",
    "STRIATUM_L_REF_CWM", "STRIATUM_R_REF_CWM", "PUTAMEN_L_REF_CWM", "PUTAMEN_R_REF_CWM",
    "CAUDATE_L_REF_CWM", "CAUDATE_R_REF_CWM",
    "STRIATUM_diff", "PUTAMEN_diff", "CAUDATE_diff",
    "STRIATUM_AI", "PUTAMEN_AI", "CAUDATE_AI",
]
WITH_NP2 = CORE_FEATURES + ["clinical_NP2PTOT"]
cols = CORE_FEATURES if FSET == "core_features" else WITH_NP2

model_fns = {
    "MLP": lambda nf, no: MLP(nf, no),
    "TabularResNet": lambda nf, no: TabularResNet(nf, no),
    "FTTransformer": lambda nf, no: FTTransformer(nf, no),
    "SAINT_simplified": lambda nf, no: SAINTSimplified(nf, no),
    "TabM_simplified": lambda nf, no: TabMSimplified(nf, no),
}

if os.path.exists(RESULTS_PATH):
    with open(RESULTS_PATH) as f:
        results = json.load(f)
else:
    results = {"generated_at": datetime.datetime.now().isoformat(), "severity": {}, "stage": {}}

results[TASK].setdefault(FSET, {})

if TASK == "severity":
    sev_df = feat[feat["clinical_severity_target_eligible"] & feat["clinical_NP3TOT"].notna()].copy()
    train, test = patient_level_train_test_split(sev_df, test_size=0.2, random_state=42)
    cols_avail = [c for c in cols if c in train.columns]
    for name, fn in model_fns.items():
        _, preds, yte = train_deep_model(fn, train, test, cols_avail, "clinical_NP3TOT", task="regression",
                                          epochs=40, patience=8, random_state=42)
        m = regression_metrics(yte, preds)
        results[TASK][FSET][name] = m
        print(f"[severity/{FSET}] {name}: MAE={m['MAE']:.2f} RMSE={m['RMSE']:.2f} R2={m['R2']:.3f}", flush=True)
else:
    stage_df = feat[feat["NHY_grouped_encoded"].notna()].copy()
    train_s, test_s = patient_level_train_test_split(stage_df, test_size=0.2, random_state=42)
    cols_avail = [c for c in cols if c in train_s.columns]
    cw = compute_class_weight("balanced", classes=np.array([0, 1, 2, 3]), y=train_s["NHY_grouped_encoded"].values)
    for name, fn in model_fns.items():
        _, preds, yte = train_deep_model(fn, train_s, test_s, cols_avail, "NHY_grouped_encoded", task="classification",
                                          n_classes=4, epochs=40, patience=8, random_state=42, class_weights=cw)
        m = classification_metrics(yte, preds)
        results[TASK][FSET][name] = {k: v for k, v in m.items() if k != "per_class_report"}
        print(f"[stage/{FSET}] {name}: bal_acc={m['balanced_accuracy']:.3f} macro_f1={m['macro_f1']:.3f} "
              f"MCC={m['MCC']:.3f} kappa={m['cohen_kappa']:.3f} acc={m['accuracy']:.3f}", flush=True)

with open(RESULTS_PATH, "w") as f:
    json.dump(results, f, indent=2, default=str)
print("saved.", flush=True)
