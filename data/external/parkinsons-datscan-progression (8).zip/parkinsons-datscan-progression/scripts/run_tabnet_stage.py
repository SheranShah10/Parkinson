import sys, json, warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, "parkinsons-datscan-progression")
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.utils.class_weight import compute_class_weight
from pytorch_tabnet.tab_model import TabNetClassifier

from src.data.loaders import load_demographics, load_updrs_ii, load_updrs_iii, load_sbr
from src.data.merge import build_master_table
from src.data.cleaning import flag_sbr_anomalies
from src.features.build_features import build_candidate_features
from src.utils.splitting import patient_level_train_test_split
from src.evaluation.metrics import classification_metrics

u3 = load_updrs_iii(path="csvs/fyp/MDS-UPDRS_Part_III_14Feb2026.csv")
sbr = load_sbr(path="csvs/fyp/Xing_Core_Lab_-_Quant_SBR_14Feb2026.csv")
demo = load_demographics(path="csvs/fyp/Demographics_14Feb2026.csv")
u2 = load_updrs_ii(path="csvs/fyp/MDS_UPDRS_Part_II__Patient_Questionnaire_14Feb2026.csv")
tables = build_master_table(demo, u2, u3, sbr, tolerance_days=90)
img = flag_sbr_anomalies(tables["imaging_anchored"])
feat = build_candidate_features(demo, img)
feat["NHY_grouped"] = feat["clinical_NHY"].map(lambda x: "3+" if pd.notna(x) and x>=3 else (str(int(x)) if pd.notna(x) else np.nan))
label_map = {"0":0,"1":1,"2":2,"3+":3}
feat["NHY_grouped_encoded"] = feat["NHY_grouped"].map(label_map)

CORE = ["AGE_AT_VISIT","SEX","HANDED","STRIATUM_REF_CWM","PUTAMEN_REF_CWM","CAUDATE_REF_CWM",
    "STRIATUM_L_REF_CWM","STRIATUM_R_REF_CWM","PUTAMEN_L_REF_CWM","PUTAMEN_R_REF_CWM",
    "CAUDATE_L_REF_CWM","CAUDATE_R_REF_CWM","STRIATUM_diff","PUTAMEN_diff","CAUDATE_diff",
    "STRIATUM_AI","PUTAMEN_AI","CAUDATE_AI"]
WITH_NP2 = CORE + ["clinical_NP2PTOT"]

def prep(train_df, test_df, cols, target):
    imp, sc = SimpleImputer(strategy="median"), StandardScaler()
    Xtr = sc.fit_transform(imp.fit_transform(train_df[cols])).astype(np.float32)
    Xte = sc.transform(imp.transform(test_df[cols])).astype(np.float32)
    return Xtr, Xte, train_df[target].values.astype(int), test_df[target].values.astype(int)

RESULTS_PATH = "experiments/logs/deep_learning_run_001.json"
with open(RESULTS_PATH) as f:
    results = json.load(f)

stage_df = feat[feat["NHY_grouped_encoded"].notna()].copy()
train_s, test_s = patient_level_train_test_split(stage_df, test_size=0.2, random_state=42)

for fset, cols in [("core_features", CORE), ("core_plus_NP2PTOT", WITH_NP2)]:
    tr_in, val_in = patient_level_train_test_split(train_s, test_size=0.15, random_state=42)
    Xtr2, Xval2, ytr2, yval2 = prep(tr_in, val_in, cols, "NHY_grouped_encoded")
    Xtr, Xte, ytr, yte = prep(train_s, test_s, cols, "NHY_grouped_encoded")
    cw = compute_class_weight("balanced", classes=np.array([0,1,2,3]), y=ytr)
    sample_weights = cw[ytr2]
    model = TabNetClassifier(seed=42, verbose=0)
    model.fit(Xtr2, ytr2, eval_set=[(Xval2, yval2)], max_epochs=100, patience=15,
              eval_metric=["balanced_accuracy"], weights=1)
    preds = model.predict(Xte)
    m = classification_metrics(yte, preds)
    results["stage"][fset]["TabNet"] = {k:v for k,v in m.items() if k!="per_class_report"}
    print(f"[stage/{fset}] TabNet: bal_acc={m['balanced_accuracy']:.3f} macro_f1={m['macro_f1']:.3f} MCC={m['MCC']:.3f} kappa={m['cohen_kappa']:.3f} acc={m['accuracy']:.3f}")

with open(RESULTS_PATH, "w") as f:
    json.dump(results, f, indent=2, default=str)
print("stage TabNet saved.")
