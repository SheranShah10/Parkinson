import sys, json, warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, "parkinsons-datscan-progression")
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.utils.class_weight import compute_class_weight
from pytorch_tabnet.tab_model import TabNetRegressor, TabNetClassifier

from src.data.loaders import load_demographics, load_updrs_ii, load_updrs_iii, load_sbr
from src.data.merge import build_master_table
from src.data.cleaning import flag_sbr_anomalies
from src.features.build_features import build_candidate_features
from src.utils.splitting import patient_level_train_test_split
from src.evaluation.metrics import regression_metrics, classification_metrics

u3 = load_updrs_iii(path="csvs/fyp/MDS-UPDRS_Part_III_14Feb2026.csv")
sbr = load_sbr(path="csvs/fyp/Xing_Core_Lab_-_Quant_SBR_14Feb2026.csv")
demo = load_demographics(path="csvs/fyp/Demographics_14Feb2026.csv")
u2 = load_updrs_ii(path="csvs/fyp/MDS_UPDRS_Part_II__Patient_Questionnaire_14Feb2026.csv")
tables = build_master_table(demo, u2, u3, sbr, tolerance_days=90)
img = flag_sbr_anomalies(tables["imaging_anchored"])
feat = build_candidate_features(demo, img)
feat["NHY_grouped"] = feat["clinical_NHY"].map(lambda x: "3+" if pd.notna(x) and x>=3 else (str(int(x)) if pd.notna(x) else np.nan))
label_map = {"0":0,"1":1,"2":2,"3+":3}
feat["NHY_grouped_encoded"] = feat["NHY_grouped"].map(label_map)

CORE = ["AGE_AT_VISIT","SEX","HANDED","STRIATUM_REF_CWM","PUTAMEN_REF_CWM","CAUDATE_REF_CWM",
    "STRIATUM_L_REF_CWM","STRIATUM_R_REF_CWM","PUTAMEN_L_REF_CWM","PUTAMEN_R_REF_CWM",
    "CAUDATE_L_REF_CWM","CAUDATE_R_REF_CWM","STRIATUM_diff","PUTAMEN_diff","CAUDATE_diff",
    "STRIATUM_AI","PUTAMEN_AI","CAUDATE_AI"]
WITH_NP2 = CORE + ["clinical_NP2PTOT"]

def prep(train_df, test_df, cols, target):
    imp, sc = SimpleImputer(strategy="median"), StandardScaler()
    Xtr = sc.fit_transform(imp.fit_transform(train_df[cols])).astype(np.float32)
    Xte = sc.transform(imp.transform(test_df[cols])).astype(np.float32)
    return Xtr, Xte, train_df[target].values, test_df[target].values

RESULTS_PATH = "experiments/logs/deep_learning_run_001.json"
with open(RESULTS_PATH) as f:
    results = json.load(f)

# ---- Severity ----
sev_df = feat[feat["clinical_severity_target_eligible"] & feat["clinical_NP3TOT"].notna()].copy()
train, test = patient_level_train_test_split(sev_df, test_size=0.2, random_state=42)
for fset, cols in [("core_features", CORE), ("core_plus_NP2PTOT", WITH_NP2)]:
    Xtr, Xte, ytr, yte = prep(train, test, cols, "clinical_NP3TOT")
    tr_in, val_in = patient_level_train_test_split(train, test_size=0.15, random_state=42)
    Xtr2, Xval2, ytr2, yval2 = prep(tr_in, val_in, cols, "clinical_NP3TOT")
    model = TabNetRegressor(seed=42, verbose=0)
    model.fit(Xtr2, ytr2.reshape(-1,1), eval_set=[(Xval2, yval2.reshape(-1,1))],
              max_epochs=100, patience=15, eval_metric=["rmse"])
    preds = model.predict(Xte).flatten()
    m = regression_metrics(yte, preds)
    results["severity"][fset]["TabNet"] = m
    print(f"[severity/{fset}] TabNet: MAE={m['MAE']:.2f} RMSE={m['RMSE']:.2f} R2={m['R2']:.3f}")

with open(RESULTS_PATH, "w") as f:
    json.dump(results, f, indent=2, default=str)
print("severity TabNet saved.")
